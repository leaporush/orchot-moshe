class Student {
  constructor(id, firstName, lastName, grade, gradeNum, donation) {
    this.id = id;
    this.firstName = firstName;
    this.lastName = lastName;
    this.grade = grade;
    this.gradeNum = gradeNum;
    this.donation = donation;
  }


}

// יצירת אובייקט מסוג משתמש
const user1 = new User(1, "John Doe", "john@example.com", 30);
